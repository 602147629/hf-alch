
var PageName = '自村';
var PageId = 'p35e37f8055ce485e98ca2e2fd9a2bee1'
var PageUrl = '自村.html'
document.title = '自村';

if (top.location != self.location)
{
	if (parent.HandleMainFrameChanged) {
		parent.HandleMainFrameChanged();
	}
}

if (window.OnLoad) OnLoad();
