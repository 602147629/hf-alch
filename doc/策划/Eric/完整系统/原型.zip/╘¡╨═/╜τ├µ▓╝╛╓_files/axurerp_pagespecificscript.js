
var PageName = '界面布局';
var PageId = 'pc1d98f4005d446a2977b1861b7d6cd03'
var PageUrl = '界面布局.html'
document.title = '界面布局';

if (top.location != self.location)
{
	if (parent.HandleMainFrameChanged) {
		parent.HandleMainFrameChanged();
	}
}

var $OnLoadVariable = '';

var $CSUM;

var hasQuery = false;
var query = window.location.hash.substring(1);
if (query.length > 0) hasQuery = true;
var vars = query.split("&");
for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if (pair[0].length > 0) eval("$" + pair[0] + " = decodeURIComponent(pair[1]);");
} 

if (hasQuery && $CSUM != 1) {
alert('Prototype Warning: The variable values were too long to pass to this page.\nIf you are using IE, using Firefox will support more data.');
}

function GetQuerystring() {
    return '#OnLoadVariable=' + encodeURIComponent($OnLoadVariable) + '&CSUM=1';
}

function PopulateVariables(value) {
  value = value.replace(/\[\[OnLoadVariable\]\]/g, $OnLoadVariable);
  value = value.replace(/\[\[PageName\]\]/g, PageName);
  return value;
}

function OnLoad(e) {

}

eval(GetDynamicPanelScript('u462', 1));

eval(GetDynamicPanelScript('u236', 1));

eval(GetDynamicPanelScript('u469', 1));

eval(GetDynamicPanelScript('u559', 1));

eval(GetDynamicPanelScript('u548', 1));

eval(GetDynamicPanelScript('u194', 1));

eval(GetDynamicPanelScript('u570', 1));

eval(GetDynamicPanelScript('u64', 1));

eval(GetDynamicPanelScript('u296', 1));

eval(GetDynamicPanelScript('u573', 1));

eval(GetDynamicPanelScript('u389', 1));

eval(GetDynamicPanelScript('u308', 1));

eval(GetDynamicPanelScript('u523', 1));

var u33 = document.getElementById('u33');
gv_vAlignTable['u33'] = 'center';
var u402 = document.getElementById('u402');
gv_vAlignTable['u402'] = 'center';
var u65 = document.getElementById('u65');

var u545 = document.getElementById('u545');
gv_vAlignTable['u545'] = 'center';
var u126 = document.getElementById('u126');

var u561 = document.getElementById('u561');
gv_vAlignTable['u561'] = 'center';
var u296 = document.getElementById('u296');

var u420 = document.getElementById('u420');
gv_vAlignTable['u420'] = 'center';
var u332 = document.getElementById('u332');
gv_vAlignTable['u332'] = 'top';
var u157 = document.getElementById('u157');
gv_vAlignTable['u157'] = 'top';
var u129 = document.getElementById('u129');

var u417 = document.getElementById('u417');

var u555 = document.getElementById('u555');

var u86 = document.getElementById('u86');
gv_vAlignTable['u86'] = 'top';
var u428 = document.getElementById('u428');
gv_vAlignTable['u428'] = 'top';
var u162 = document.getElementById('u162');
gv_vAlignTable['u162'] = 'center';
var u0 = document.getElementById('u0');

var u262 = document.getElementById('u262');
gv_vAlignTable['u262'] = 'top';
var u131 = document.getElementById('u131');

var u42 = document.getElementById('u42');

var u564 = document.getElementById('u564');

var u506 = document.getElementById('u506');

var u493 = document.getElementById('u493');

var u82 = document.getElementById('u82');
gv_vAlignTable['u82'] = 'top';
var u74 = document.getElementById('u74');
gv_vAlignTable['u74'] = 'top';
var u216 = document.getElementById('u216');
gv_vAlignTable['u216'] = 'center';
var u99 = document.getElementById('u99');
gv_vAlignTable['u99'] = 'top';
var u576 = document.getElementById('u576');

u576.style.cursor = 'pointer';
if (bIE) u576.attachEvent("onclick", Clicku576);
else u576.addEventListener("click", Clicku576, true);
function Clicku576(e)
{

if (true) {

	SetPanelVisibilityu573("hidden");

}

}

var u386 = document.getElementById('u386');

var u510 = document.getElementById('u510');
gv_vAlignTable['u510'] = 'top';
var u277 = document.getElementById('u277');
gv_vAlignTable['u277'] = 'top';
var u234 = document.getElementById('u234');

u234.style.cursor = 'pointer';
if (bIE) u234.attachEvent("onclick", Clicku234);
else u234.addEventListener("click", Clicku234, true);
function Clicku234(e)
{

if (true) {

	SetPanelVisibilityu194("hidden");

}

}

var u104 = document.getElementById('u104');

var u242 = document.getElementById('u242');
gv_vAlignTable['u242'] = 'center';
var u323 = document.getElementById('u323');
gv_vAlignTable['u323'] = 'top';
var u518 = document.getElementById('u518');
gv_vAlignTable['u518'] = 'center';
var u391 = document.getElementById('u391');
gv_vAlignTable['u391'] = 'center';
var u541 = document.getElementById('u541');
gv_vAlignTable['u541'] = 'center';
var u440 = document.getElementById('u440');

var u229 = document.getElementById('u229');
gv_vAlignTable['u229'] = 'top';
var u559 = document.getElementById('u559');

var u399 = document.getElementById('u399');
gv_vAlignTable['u399'] = 'top';
var u366 = document.getElementById('u366');
gv_vAlignTable['u366'] = 'center';
var u51 = document.getElementById('u51');
gv_vAlignTable['u51'] = 'center';
var u459 = document.getElementById('u459');
gv_vAlignTable['u459'] = 'center';
var u331 = document.getElementById('u331');
gv_vAlignTable['u331'] = 'top';
var u270 = document.getElementById('u270');
gv_vAlignTable['u270'] = 'top';
var u128 = document.getElementById('u128');

u128.style.cursor = 'pointer';
if (bIE) u128.attachEvent("onclick", Clicku128);
else u128.addEventListener("click", Clicku128, true);
function Clicku128(e)
{

if (true) {

	SetPanelVisibilityu236("");

}

}

var u68 = document.getElementById('u68');
gv_vAlignTable['u68'] = 'center';
var u416 = document.getElementById('u416');
gv_vAlignTable['u416'] = 'center';
var u257 = document.getElementById('u257');

var u306 = document.getElementById('u306');
gv_vAlignTable['u306'] = 'center';
var u278 = document.getElementById('u278');

var u240 = document.getElementById('u240');
gv_vAlignTable['u240'] = 'center';
var u261 = document.getElementById('u261');
gv_vAlignTable['u261'] = 'top';
var u187 = document.getElementById('u187');

var u324 = document.getElementById('u324');
gv_vAlignTable['u324'] = 'top';
var u346 = document.getElementById('u346');
gv_vAlignTable['u346'] = 'center';
var u32 = document.getElementById('u32');

var u27 = document.getElementById('u27');
gv_vAlignTable['u27'] = 'top';
var u192 = document.getElementById('u192');
gv_vAlignTable['u192'] = 'center';
var u578 = document.getElementById('u578');

u578.style.cursor = 'pointer';
if (bIE) u578.attachEvent("onclick", Clicku578);
else u578.addEventListener("click", Clicku578, true);
function Clicku578(e)
{

if (true) {

	SetPanelVisibilityu573("hidden");

}

}

var u319 = document.getElementById('u319');
gv_vAlignTable['u319'] = 'top';
var u108 = document.getElementById('u108');

var u212 = document.getElementById('u212');

var u489 = document.getElementById('u489');
gv_vAlignTable['u489'] = 'top';
var u549 = document.getElementById('u549');

var u60 = document.getElementById('u60');

var u59 = document.getElementById('u59');
gv_vAlignTable['u59'] = 'center';
var u5 = document.getElementById('u5');

var u360 = document.getElementById('u360');
gv_vAlignTable['u360'] = 'center';
var u573 = document.getElementById('u573');

var u103 = document.getElementById('u103');
gv_vAlignTable['u103'] = 'center';
var u529 = document.getElementById('u529');
gv_vAlignTable['u529'] = 'center';
var u9 = document.getElementById('u9');
gv_vAlignTable['u9'] = 'top';
var u107 = document.getElementById('u107');
gv_vAlignTable['u107'] = 'top';
var u368 = document.getElementById('u368');
gv_vAlignTable['u368'] = 'center';
var u401 = document.getElementById('u401');

var u365 = document.getElementById('u365');

var u330 = document.getElementById('u330');
gv_vAlignTable['u330'] = 'center';
var u314 = document.getElementById('u314');
gv_vAlignTable['u314'] = 'center';
var u125 = document.getElementById('u125');
gv_vAlignTable['u125'] = 'center';
var u36 = document.getElementById('u36');

var u295 = document.getElementById('u295');

u295.style.cursor = 'pointer';
if (bIE) u295.attachEvent("onclick", Clicku295);
else u295.addEventListener("click", Clicku295, true);
function Clicku295(e)
{

if (true) {

	SetPanelVisibilityu296("");

}

}

var u415 = document.getElementById('u415');

var u256 = document.getElementById('u256');
gv_vAlignTable['u256'] = 'top';
var u143 = document.getElementById('u143');
gv_vAlignTable['u143'] = 'top';
var u454 = document.getElementById('u454');

var u122 = document.getElementById('u122');
gv_vAlignTable['u122'] = 'center';
var u260 = document.getElementById('u260');
gv_vAlignTable['u260'] = 'center';
var u450 = document.getElementById('u450');

var u505 = document.getElementById('u505');
gv_vAlignTable['u505'] = 'center';
var u504 = document.getElementById('u504');

var u138 = document.getElementById('u138');
gv_vAlignTable['u138'] = 'center';
var u345 = document.getElementById('u345');

var u474 = document.getElementById('u474');

var u439 = document.getElementById('u439');
gv_vAlignTable['u439'] = 'center';
var u349 = document.getElementById('u349');

var u211 = document.getElementById('u211');
gv_vAlignTable['u211'] = 'top';
var u231 = document.getElementById('u231');
gv_vAlignTable['u231'] = 'top';
var u169 = document.getElementById('u169');
gv_vAlignTable['u169'] = 'top';
var u215 = document.getElementById('u215');

var u137 = document.getElementById('u137');

var u275 = document.getElementById('u275');
gv_vAlignTable['u275'] = 'top';
var u539 = document.getElementById('u539');
gv_vAlignTable['u539'] = 'center';
var u102 = document.getElementById('u102');

var u180 = document.getElementById('u180');
gv_vAlignTable['u180'] = 'top';
var u369 = document.getElementById('u369');

var u85 = document.getElementById('u85');
gv_vAlignTable['u85'] = 'top';
var u77 = document.getElementById('u77');
gv_vAlignTable['u77'] = 'top';
var u300 = document.getElementById('u300');
gv_vAlignTable['u300'] = 'center';
var u141 = document.getElementById('u141');
gv_vAlignTable['u141'] = 'top';
var u20 = document.getElementById('u20');
gv_vAlignTable['u20'] = 'top';
var u226 = document.getElementById('u226');
gv_vAlignTable['u226'] = 'top';
var u364 = document.getElementById('u364');
gv_vAlignTable['u364'] = 'center';
var u540 = document.getElementById('u540');

var u458 = document.getElementById('u458');

var u264 = document.getElementById('u264');

var u109 = document.getElementById('u109');
gv_vAlignTable['u109'] = 'center';
var u476 = document.getElementById('u476');

var u414 = document.getElementById('u414');
gv_vAlignTable['u414'] = 'center';
var u255 = document.getElementById('u255');
gv_vAlignTable['u255'] = 'top';
var u183 = document.getElementById('u183');

u183.style.cursor = 'pointer';
if (bIE) u183.attachEvent("onclick", Clicku183);
else u183.addEventListener("click", Clicku183, true);
function Clicku183(e)
{

if (true) {

	SetPanelVisibilityu194("");

}

}

var u424 = document.getElementById('u424');
gv_vAlignTable['u424'] = 'center';
var u259 = document.getElementById('u259');

var u13 = document.getElementById('u13');

var u466 = document.getElementById('u466');
gv_vAlignTable['u466'] = 'center';
var u305 = document.getElementById('u305');

u305.style.cursor = 'pointer';
if (bIE) u305.attachEvent("onclick", Clicku305);
else u305.addEventListener("click", Clicku305, true);
function Clicku305(e)
{

if (true) {

	SetPanelVisibilityu296("hidden");

}

}

var u54 = document.getElementById('u54');

var u387 = document.getElementById('u387');
gv_vAlignTable['u387'] = 'top';
var u206 = document.getElementById('u206');
gv_vAlignTable['u206'] = 'top';
var u344 = document.getElementById('u344');
gv_vAlignTable['u344'] = 'top';
var u94 = document.getElementById('u94');
gv_vAlignTable['u94'] = 'top';
var u186 = document.getElementById('u186');

u186.style.cursor = 'pointer';
if (bIE) u186.attachEvent("onclick", Clicku186);
else u186.addEventListener("click", Clicku186, true);
function Clicku186(e)
{

if (true) {

	SetPanelVisibilityu308("");

	SetPanelVisibilityu64("hidden");

}

}
gv_vAlignTable['u186'] = 'top';
var u279 = document.getElementById('u279');
gv_vAlignTable['u279'] = 'center';
var u336 = document.getElementById('u336');

var u480 = document.getElementById('u480');

var u210 = document.getElementById('u210');
gv_vAlignTable['u210'] = 'center';
var u318 = document.getElementById('u318');
gv_vAlignTable['u318'] = 'top';
var u191 = document.getElementById('u191');

var u136 = document.getElementById('u136');
gv_vAlignTable['u136'] = 'center';
var u341 = document.getElementById('u341');

var u571 = document.getElementById('u571');

var u101 = document.getElementById('u101');
gv_vAlignTable['u101'] = 'center';
var u488 = document.getElementById('u488');
gv_vAlignTable['u488'] = 'top';
var u199 = document.getElementById('u199');
gv_vAlignTable['u199'] = 'top';
var u31 = document.getElementById('u31');
gv_vAlignTable['u31'] = 'center';
var u140 = document.getElementById('u140');
gv_vAlignTable['u140'] = 'center';
var u48 = document.getElementById('u48');

u48.style.cursor = 'pointer';
if (bIE) u48.attachEvent("onclick", Clicku48);
else u48.addEventListener("click", Clicku48, true);
function Clicku48(e)
{

if (true) {

	SetPanelVisibilityu523("");

}

}

var u63 = document.getElementById('u63');
gv_vAlignTable['u63'] = 'center';
var u106 = document.getElementById('u106');
gv_vAlignTable['u106'] = 'top';
var u88 = document.getElementById('u88');

var u570 = document.getElementById('u570');

var u400 = document.getElementById('u400');
gv_vAlignTable['u400'] = 'top';
var u111 = document.getElementById('u111');
gv_vAlignTable['u111'] = 'center';
var u294 = document.getElementById('u294');

u294.style.cursor = 'pointer';
if (bIE) u294.attachEvent("onclick", Clicku294);
else u294.addEventListener("click", Clicku294, true);
function Clicku294(e)
{

if (true) {

	SetPanelVisibilityu296("");

}

}

var u408 = document.getElementById('u408');
gv_vAlignTable['u408'] = 'center';
var u120 = document.getElementById('u120');
gv_vAlignTable['u120'] = 'top';
var u119 = document.getElementById('u119');
gv_vAlignTable['u119'] = 'top';
var u537 = document.getElementById('u537');
gv_vAlignTable['u537'] = 'center';
var u205 = document.getElementById('u205');
gv_vAlignTable['u205'] = 'top';
var u302 = document.getElementById('u302');
gv_vAlignTable['u302'] = 'center';
var u289 = document.getElementById('u289');
gv_vAlignTable['u289'] = 'top';
var u40 = document.getElementById('u40');

u40.style.cursor = 'pointer';
if (bIE) u40.attachEvent("onclick", Clicku40);
else u40.addEventListener("click", Clicku40, true);
function Clicku40(e)
{

if (true) {

	SetPanelVisibilityu469("");

}

}

var u3 = document.getElementById('u3');

var u390 = document.getElementById('u390');

var u160 = document.getElementById('u160');
gv_vAlignTable['u160'] = 'top';
var u72 = document.getElementById('u72');
gv_vAlignTable['u72'] = 'top';
var u80 = document.getElementById('u80');
gv_vAlignTable['u80'] = 'top';
var u467 = document.getElementById('u467');

u467.style.cursor = 'pointer';
if (bIE) u467.attachEvent("onclick", Clicku467);
else u467.addEventListener("click", Clicku467, true);
function Clicku467(e)
{

if (true) {

	SetPanelVisibilityu462("hidden");

}

}

var u163 = document.getElementById('u163');

var u281 = document.getElementById('u281');
gv_vAlignTable['u281'] = 'center';
var u574 = document.getElementById('u574');

var u503 = document.getElementById('u503');
gv_vAlignTable['u503'] = 'center';
var u168 = document.getElementById('u168');
gv_vAlignTable['u168'] = 'top';
var u227 = document.getElementById('u227');

var u546 = document.getElementById('u546');

u546.style.cursor = 'pointer';
if (bIE) u546.attachEvent("onclick", Clicku546);
else u546.addEventListener("click", Clicku546, true);
function Clicku546(e)
{

if (true) {

	SetPanelVisibilityu559("");

	SetPanelVisibilityu548("hidden");

}

}

var u96 = document.getElementById('u96');
gv_vAlignTable['u96'] = 'top';
var u384 = document.getElementById('u384');

var u521 = document.getElementById('u521');

u521.style.cursor = 'pointer';
if (bIE) u521.attachEvent("onclick", Clicku521);
else u521.addEventListener("click", Clicku521, true);
function Clicku521(e)
{

if (true) {

	SetPanelVisibilityu308("");

}

}

var u16 = document.getElementById('u16');
gv_vAlignTable['u16'] = 'center';
var u362 = document.getElementById('u362');
gv_vAlignTable['u362'] = 'center';
var u232 = document.getElementById('u232');
gv_vAlignTable['u232'] = 'top';
var u12 = document.getElementById('u12');
gv_vAlignTable['u12'] = 'top';
var u447 = document.getElementById('u447');
gv_vAlignTable['u447'] = 'center';
var u333 = document.getElementById('u333');
gv_vAlignTable['u333'] = 'top';
var u522 = document.getElementById('u522');
gv_vAlignTable['u522'] = 'center';
var u209 = document.getElementById('u209');

var u276 = document.getElementById('u276');
gv_vAlignTable['u276'] = 'top';
var u421 = document.getElementById('u421');
gv_vAlignTable['u421'] = 'top';
var u154 = document.getElementById('u154');

var u451 = document.getElementById('u451');
gv_vAlignTable['u451'] = 'center';
var u334 = document.getElementById('u334');

var u282 = document.getElementById('u282');
gv_vAlignTable['u282'] = 'top';
var u523 = document.getElementById('u523');

var u514 = document.getElementById('u514');
gv_vAlignTable['u514'] = 'top';
var u377 = document.getElementById('u377');

var u258 = document.getElementById('u258');
gv_vAlignTable['u258'] = 'center';
var u342 = document.getElementById('u342');
gv_vAlignTable['u342'] = 'top';
var u317 = document.getElementById('u317');
gv_vAlignTable['u317'] = 'top';
var u139 = document.getElementById('u139');

var u25 = document.getElementById('u25');
gv_vAlignTable['u25'] = 'center';
var u487 = document.getElementById('u487');
gv_vAlignTable['u487'] = 'top';
var u284 = document.getElementById('u284');
gv_vAlignTable['u284'] = 'top';
var u525 = document.getElementById('u525');
gv_vAlignTable['u525'] = 'center';
var u179 = document.getElementById('u179');
gv_vAlignTable['u179'] = 'top';
var u185 = document.getElementById('u185');

u185.style.cursor = 'pointer';
if (bIE) u185.attachEvent("onclick", Clicku185);
else u185.addEventListener("click", Clicku185, true);
function Clicku185(e)
{

if (true) {

	SetPanelVisibilityu194("");

}

}

var u335 = document.getElementById('u335');
gv_vAlignTable['u335'] = 'top';
var u57 = document.getElementById('u57');
gv_vAlignTable['u57'] = 'center';
var u134 = document.getElementById('u134');
gv_vAlignTable['u134'] = 'center';
var u431 = document.getElementById('u431');
gv_vAlignTable['u431'] = 'top';
var u526 = document.getElementById('u526');

var u92 = document.getElementById('u92');
gv_vAlignTable['u92'] = 'top';
var u228 = document.getElementById('u228');
gv_vAlignTable['u228'] = 'center';
var u97 = document.getElementById('u97');
gv_vAlignTable['u97'] = 'top';
var u516 = document.getElementById('u516');
gv_vAlignTable['u516'] = 'center';
var u190 = document.getElementById('u190');
gv_vAlignTable['u190'] = 'center';
var u353 = document.getElementById('u353');

var u37 = document.getElementById('u37');
gv_vAlignTable['u37'] = 'center';
var u198 = document.getElementById('u198');
gv_vAlignTable['u198'] = 'center';
var u348 = document.getElementById('u348');
gv_vAlignTable['u348'] = 'center';
var u253 = document.getElementById('u253');
gv_vAlignTable['u253'] = 'center';
var u407 = document.getElementById('u407');

var u19 = document.getElementById('u19');
gv_vAlignTable['u19'] = 'top';
var u208 = document.getElementById('u208');
gv_vAlignTable['u208'] = 'top';
var u34 = document.getElementById('u34');

var u153 = document.getElementById('u153');
gv_vAlignTable['u153'] = 'center';
var u412 = document.getElementById('u412');
gv_vAlignTable['u412'] = 'center';
var u66 = document.getElementById('u66');
gv_vAlignTable['u66'] = 'center';
var u123 = document.getElementById('u123');
gv_vAlignTable['u123'] = 'top';
var u376 = document.getElementById('u376');
gv_vAlignTable['u376'] = 'center';
var u280 = document.getElementById('u280');

var u430 = document.getElementById('u430');
gv_vAlignTable['u430'] = 'top';
var u118 = document.getElementById('u118');
gv_vAlignTable['u118'] = 'top';
var u167 = document.getElementById('u167');
gv_vAlignTable['u167'] = 'top';
var u288 = document.getElementById('u288');
gv_vAlignTable['u288'] = 'top';
var u438 = document.getElementById('u438');

var u465 = document.getElementById('u465');

var u11 = document.getElementById('u11');
gv_vAlignTable['u11'] = 'center';
var u515 = document.getElementById('u515');

var u28 = document.getElementById('u28');
gv_vAlignTable['u28'] = 'top';
var u356 = document.getElementById('u356');
gv_vAlignTable['u356'] = 'center';
var u43 = document.getElementById('u43');
gv_vAlignTable['u43'] = 'center';
var u502 = document.getElementById('u502');

var u75 = document.getElementById('u75');

var u554 = document.getElementById('u554');
gv_vAlignTable['u554'] = 'center';
var u83 = document.getElementById('u83');

var u222 = document.getElementById('u222');
gv_vAlignTable['u222'] = 'center';
var u213 = document.getElementById('u213');
gv_vAlignTable['u213'] = 'center';
var u383 = document.getElementById('u383');
gv_vAlignTable['u383'] = 'top';
var u520 = document.getElementById('u520');
gv_vAlignTable['u520'] = 'center';
var u445 = document.getElementById('u445');
gv_vAlignTable['u445'] = 'center';
var u244 = document.getElementById('u244');
gv_vAlignTable['u244'] = 'center';
var u568 = document.getElementById('u568');

var u311 = document.getElementById('u311');

var u152 = document.getElementById('u152');

var u432 = document.getElementById('u432');

var u528 = document.getElementById('u528');

var u239 = document.getElementById('u239');

u239.style.cursor = 'pointer';
if (bIE) u239.attachEvent("onclick", Clicku239);
else u239.addEventListener("click", Clicku239, true);
function Clicku239(e)
{

if (true) {

	SetPanelVisibilityu236("hidden");

}

}

var u237 = document.getElementById('u237');

var u1 = document.getElementById('u1');
gv_vAlignTable['u1'] = 'center';
var u512 = document.getElementById('u512');
gv_vAlignTable['u512'] = 'top';
var u202 = document.getElementById('u202');
gv_vAlignTable['u202'] = 'top';
var u52 = document.getElementById('u52');

var u469 = document.getElementById('u469');

var u490 = document.getElementById('u490');
gv_vAlignTable['u490'] = 'top';
var u69 = document.getElementById('u69');

var u434 = document.getElementById('u434');
gv_vAlignTable['u434'] = 'top';
var u519 = document.getElementById('u519');

u519.style.cursor = 'pointer';
if (bIE) u519.attachEvent("onclick", Clicku519);
else u519.addEventListener("click", Clicku519, true);
function Clicku519(e)
{

if (true) {

	SetPanelVisibilityu64("");

}

}

var u316 = document.getElementById('u316');
gv_vAlignTable['u316'] = 'center';
var u30 = document.getElementById('u30');

var u326 = document.getElementById('u326');
gv_vAlignTable['u326'] = 'top';
var u246 = document.getElementById('u246');
gv_vAlignTable['u246'] = 'top';
var u194 = document.getElementById('u194');

var u435 = document.getElementById('u435');

var u132 = document.getElementById('u132');
gv_vAlignTable['u132'] = 'center';
var u184 = document.getElementById('u184');

u184.style.cursor = 'pointer';
if (bIE) u184.attachEvent("onclick", Clicku184);
else u184.addEventListener("click", Clicku184, true);
function Clicku184(e)
{

if (true) {

	SetPanelVisibilityu194("");

}

}

var u347 = document.getElementById('u347');

var u195 = document.getElementById('u195');

var u355 = document.getElementById('u355');

u355.style.cursor = 'pointer';
if (bIE) u355.attachEvent("onclick", Clicku355);
else u355.addEventListener("click", Clicku355, true);
function Clicku355(e)
{

if (true) {

	SetPanelVisibilityu308("hidden");

}

}

var u449 = document.getElementById('u449');
gv_vAlignTable['u449'] = 'center';
var u491 = document.getElementById('u491');

var u23 = document.getElementById('u23');
gv_vAlignTable['u23'] = 'center';
var u553 = document.getElementById('u553');

var u221 = document.getElementById('u221');

var u352 = document.getElementById('u352');
gv_vAlignTable['u352'] = 'top';
var u499 = document.getElementById('u499');
gv_vAlignTable['u499'] = 'top';
var u61 = document.getElementById('u61');
gv_vAlignTable['u61'] = 'center';
var u293 = document.getElementById('u293');

u293.style.cursor = 'pointer';
if (bIE) u293.attachEvent("onclick", Clicku293);
else u293.addEventListener("click", Clicku293, true);
function Clicku293(e)
{

if (true) {

	SetPanelVisibilityu296("");

}

}

var u370 = document.getElementById('u370');
gv_vAlignTable['u370'] = 'center';
var u283 = document.getElementById('u283');
gv_vAlignTable['u283'] = 'top';
var u78 = document.getElementById('u78');
gv_vAlignTable['u78'] = 'top';
var u310 = document.getElementById('u310');
gv_vAlignTable['u310'] = 'center';
var u151 = document.getElementById('u151');
gv_vAlignTable['u151'] = 'center';
var u117 = document.getElementById('u117');
gv_vAlignTable['u117'] = 'center';
var u378 = document.getElementById('u378');
gv_vAlignTable['u378'] = 'center';
var u21 = document.getElementById('u21');
gv_vAlignTable['u21'] = 'top';
var u236 = document.getElementById('u236');

var u374 = document.getElementById('u374');
gv_vAlignTable['u374'] = 'center';
var u201 = document.getElementById('u201');
gv_vAlignTable['u201'] = 'center';
var u468 = document.getElementById('u468');
gv_vAlignTable['u468'] = 'center';
var u411 = document.getElementById('u411');

var u135 = document.getElementById('u135');

var u127 = document.getElementById('u127');
gv_vAlignTable['u127'] = 'center';
var u292 = document.getElementById('u292');

u292.style.cursor = 'pointer';
if (bIE) u292.attachEvent("onclick", Clicku292);
else u292.addEventListener("click", Clicku292, true);
function Clicku292(e)
{

if (true) {

	SetPanelVisibilityu296("");

}

}

var u419 = document.getElementById('u419');

var u325 = document.getElementById('u325');
gv_vAlignTable['u325'] = 'top';
var u463 = document.getElementById('u463');

var u166 = document.getElementById('u166');
gv_vAlignTable['u166'] = 'center';
var u70 = document.getElementById('u70');
gv_vAlignTable['u70'] = 'center';
var u6 = document.getElementById('u6');
gv_vAlignTable['u6'] = 'center';
var u397 = document.getElementById('u397');
gv_vAlignTable['u397'] = 'top';
var u460 = document.getElementById('u460');

u460.style.cursor = 'pointer';
if (bIE) u460.attachEvent("onclick", Clicku460);
else u460.addEventListener("click", Clicku460, true);
function Clicku460(e)
{

if (true) {

	SetPanelVisibilityu389("hidden");

	SetPanelVisibilityu462("hidden");

}

}

var u171 = document.getElementById('u171');
gv_vAlignTable['u171'] = 'top';
var u113 = document.getElementById('u113');

var u524 = document.getElementById('u524');

var u552 = document.getElementById('u552');
gv_vAlignTable['u552'] = 'center';
var u207 = document.getElementById('u207');
gv_vAlignTable['u207'] = 'top';
var u220 = document.getElementById('u220');
gv_vAlignTable['u220'] = 'top';
var u501 = document.getElementById('u501');
gv_vAlignTable['u501'] = 'center';
var u14 = document.getElementById('u14');
gv_vAlignTable['u14'] = 'center';
var u146 = document.getElementById('u146');

var u443 = document.getElementById('u443');
gv_vAlignTable['u443'] = 'center';
var u427 = document.getElementById('u427');
gv_vAlignTable['u427'] = 'top';
var u225 = document.getElementById('u225');
gv_vAlignTable['u225'] = 'center';
var u46 = document.getElementById('u46');

var u382 = document.getElementById('u382');
gv_vAlignTable['u382'] = 'center';
var u517 = document.getElementById('u517');

var u509 = document.getElementById('u509');
gv_vAlignTable['u509'] = 'center';
var u567 = document.getElementById('u567');
gv_vAlignTable['u567'] = 'center';
var u150 = document.getElementById('u150');

var u230 = document.getElementById('u230');
gv_vAlignTable['u230'] = 'top';
var u39 = document.getElementById('u39');
gv_vAlignTable['u39'] = 'center';
var u373 = document.getElementById('u373');

var u329 = document.getElementById('u329');

var u238 = document.getElementById('u238');
gv_vAlignTable['u238'] = 'center';
var u532 = document.getElementById('u532');

var u558 = document.getElementById('u558');
gv_vAlignTable['u558'] = 'center';
var u165 = document.getElementById('u165');

var u462 = document.getElementById('u462');

var u533 = document.getElementById('u533');
gv_vAlignTable['u533'] = 'center';
var u269 = document.getElementById('u269');
gv_vAlignTable['u269'] = 'top';
var u130 = document.getElementById('u130');
gv_vAlignTable['u130'] = 'center';
var u315 = document.getElementById('u315');

var u55 = document.getElementById('u55');
gv_vAlignTable['u55'] = 'center';
var u534 = document.getElementById('u534');

u534.style.cursor = 'pointer';
if (bIE) u534.attachEvent("onclick", Clicku534);
else u534.addEventListener("click", Clicku534, true);
function Clicku534(e)
{

if (true) {

	SetPanelVisibilityu573("");

}

}

if (bIE) u534.attachEvent("onmouseover", MouseOveru534);
else u534.addEventListener("mouseover", MouseOveru534, true);
function MouseOveru534(e)
{
if (!IsTrueMouseOver('u534',e)) return;
if (true) {

	SetPanelVisibilityu570("");

}

}

if (bIE) u534.attachEvent("onmouseout", MouseOutu534);
else u534.addEventListener("mouseout", MouseOutu534, true);
function MouseOutu534(e)
{
if (!IsTrueMouseOut('u534',e)) return;
if (true) {

	SetPanelVisibilityu570("hidden");

}

}

var u485 = document.getElementById('u485');
gv_vAlignTable['u485'] = 'center';
var u95 = document.getElementById('u95');

var u196 = document.getElementById('u196');
gv_vAlignTable['u196'] = 'center';
var u254 = document.getElementById('u254');
gv_vAlignTable['u254'] = 'top';
var u320 = document.getElementById('u320');
gv_vAlignTable['u320'] = 'top';
var u535 = document.getElementById('u535');
gv_vAlignTable['u535'] = 'center';
var u337 = document.getElementById('u337');
gv_vAlignTable['u337'] = 'center';
var u477 = document.getElementById('u477');
gv_vAlignTable['u477'] = 'center';
var u304 = document.getElementById('u304');
gv_vAlignTable['u304'] = 'top';
var u145 = document.getElementById('u145');
gv_vAlignTable['u145'] = 'top';
var u442 = document.getElementById('u442');

var u351 = document.getElementById('u351');
gv_vAlignTable['u351'] = 'top';
var u475 = document.getElementById('u475');
gv_vAlignTable['u475'] = 'center';
var u498 = document.getElementById('u498');
gv_vAlignTable['u498'] = 'top';
var u527 = document.getElementById('u527');
gv_vAlignTable['u527'] = 'center';
var u359 = document.getElementById('u359');

var u375 = document.getElementById('u375');

var u105 = document.getElementById('u105');
gv_vAlignTable['u105'] = 'center';
var u566 = document.getElementById('u566');

var u531 = document.getElementById('u531');
gv_vAlignTable['u531'] = 'center';
var u372 = document.getElementById('u372');
gv_vAlignTable['u372'] = 'center';
var u64 = document.getElementById('u64');

var u328 = document.getElementById('u328');
gv_vAlignTable['u328'] = 'top';
var u116 = document.getElementById('u116');

var u452 = document.getElementById('u452');
gv_vAlignTable['u452'] = 'top';
var u89 = document.getElementById('u89');
gv_vAlignTable['u89'] = 'top';
var u100 = document.getElementById('u100');

var u286 = document.getElementById('u286');
gv_vAlignTable['u286'] = 'top';
var u385 = document.getElementById('u385');
gv_vAlignTable['u385'] = 'center';
var u453 = document.getElementById('u453');
gv_vAlignTable['u453'] = 'top';
var u147 = document.getElementById('u147');
gv_vAlignTable['u147'] = 'center';
var u461 = document.getElementById('u461');
gv_vAlignTable['u461'] = 'center';
var u418 = document.getElementById('u418');
gv_vAlignTable['u418'] = 'center';
var u291 = document.getElementById('u291');

u291.style.cursor = 'pointer';
if (bIE) u291.attachEvent("onclick", Clicku291);
else u291.addEventListener("click", Clicku291, true);
function Clicku291(e)
{

if (true) {

	SetPanelVisibilityu296("");

}

}

var u395 = document.getElementById('u395');
gv_vAlignTable['u395'] = 'top';
var u441 = document.getElementById('u441');
gv_vAlignTable['u441'] = 'center';
var u214 = document.getElementById('u214');
gv_vAlignTable['u214'] = 'top';
var u308 = document.getElementById('u308');

var u149 = document.getElementById('u149');
gv_vAlignTable['u149'] = 'center';
var u299 = document.getElementById('u299');

var u41 = document.getElementById('u41');
gv_vAlignTable['u41'] = 'center';
var u550 = document.getElementById('u550');
gv_vAlignTable['u550'] = 'center';
var u170 = document.getElementById('u170');
gv_vAlignTable['u170'] = 'top';
var u58 = document.getElementById('u58');

var u45 = document.getElementById('u45');
gv_vAlignTable['u45'] = 'center';
var u73 = document.getElementById('u73');
gv_vAlignTable['u73'] = 'top';
var u303 = document.getElementById('u303');
gv_vAlignTable['u303'] = 'top';
var u144 = document.getElementById('u144');
gv_vAlignTable['u144'] = 'top';
var u433 = document.getElementById('u433');
gv_vAlignTable['u433'] = 'center';
var u98 = document.getElementById('u98');
gv_vAlignTable['u98'] = 'top';
var u178 = document.getElementById('u178');
gv_vAlignTable['u178'] = 'center';
var u500 = document.getElementById('u500');

var u224 = document.getElementById('u224');

var u393 = document.getElementById('u393');
gv_vAlignTable['u393'] = 'center';
var u565 = document.getElementById('u565');
gv_vAlignTable['u565'] = 'center';
var u381 = document.getElementById('u381');

var u572 = document.getElementById('u572');
gv_vAlignTable['u572'] = 'center';
var u233 = document.getElementById('u233');
gv_vAlignTable['u233'] = 'top';
var u371 = document.getElementById('u371');

var u219 = document.getElementById('u219');
gv_vAlignTable['u219'] = 'top';
var u456 = document.getElementById('u456');

var u389 = document.getElementById('u389');

var u50 = document.getElementById('u50');

var u4 = document.getElementById('u4');
gv_vAlignTable['u4'] = 'center';
var u273 = document.getElementById('u273');

var u322 = document.getElementById('u322');
gv_vAlignTable['u322'] = 'center';
var u90 = document.getElementById('u90');

var u8 = document.getElementById('u8');
gv_vAlignTable['u8'] = 'center';
var u486 = document.getElementById('u486');
gv_vAlignTable['u486'] = 'top';
var u394 = document.getElementById('u394');
gv_vAlignTable['u394'] = 'top';
var u268 = document.getElementById('u268');
gv_vAlignTable['u268'] = 'top';
var u327 = document.getElementById('u327');

var u444 = document.getElementById('u444');

var u252 = document.getElementById('u252');

var u484 = document.getElementById('u484');

u484.style.cursor = 'pointer';
if (bIE) u484.attachEvent("onclick", Clicku484);
else u484.addEventListener("click", Clicku484, true);
function Clicku484(e)
{

if (true) {

	SetPanelVisibilityu469("hidden");

}

}

var u508 = document.getElementById('u508');

var u26 = document.getElementById('u26');
gv_vAlignTable['u26'] = 'top';
var u182 = document.getElementById('u182');
gv_vAlignTable['u182'] = 'top';
var u547 = document.getElementById('u547');
gv_vAlignTable['u547'] = 'center';
var u309 = document.getElementById('u309');

var u569 = document.getElementById('u569');
gv_vAlignTable['u569'] = 'center';
var u379 = document.getElementById('u379');
gv_vAlignTable['u379'] = 'top';
var u446 = document.getElementById('u446');

var u350 = document.getElementById('u350');
gv_vAlignTable['u350'] = 'center';
var u203 = document.getElementById('u203');

var u426 = document.getElementById('u426');
gv_vAlignTable['u426'] = 'top';
var u241 = document.getElementById('u241');

var u172 = document.getElementById('u172');
gv_vAlignTable['u172'] = 'top';
var u361 = document.getElementById('u361');

var u204 = document.getElementById('u204');
gv_vAlignTable['u204'] = 'center';
var u358 = document.getElementById('u358');
gv_vAlignTable['u358'] = 'center';
var u455 = document.getElementById('u455');
gv_vAlignTable['u455'] = 'center';
var u173 = document.getElementById('u173');
gv_vAlignTable['u173'] = 'top';
var u398 = document.getElementById('u398');
gv_vAlignTable['u398'] = 'top';
var u577 = document.getElementById('u577');
gv_vAlignTable['u577'] = 'center';
var u115 = document.getElementById('u115');
gv_vAlignTable['u115'] = 'top';
var u35 = document.getElementById('u35');
gv_vAlignTable['u35'] = 'center';
var u321 = document.getElementById('u321');

var u81 = document.getElementById('u81');

var u285 = document.getElementById('u285');
gv_vAlignTable['u285'] = 'top';
var u422 = document.getElementById('u422');
gv_vAlignTable['u422'] = 'top';
var u406 = document.getElementById('u406');

u406.style.cursor = 'pointer';
if (bIE) u406.attachEvent("onclick", Clicku406);
else u406.addEventListener("click", Clicku406, true);
function Clicku406(e)
{

if (true) {

	SetPanelVisibilityu462("");

}

}

var u67 = document.getElementById('u67');

var u544 = document.getElementById('u544');

u544.style.cursor = 'pointer';
if (bIE) u544.attachEvent("onclick", Clicku544);
else u544.addEventListener("click", Clicku544, true);
function Clicku544(e)
{

if (true) {

	SetPanelVisibilityu548("");

	SetPanelVisibilityu559("hidden");

}

}

var u133 = document.getElementById('u133');

var u479 = document.getElementById('u479');
gv_vAlignTable['u479'] = 'center';
var u290 = document.getElementById('u290');
gv_vAlignTable['u290'] = 'top';
var u410 = document.getElementById('u410');
gv_vAlignTable['u410'] = 'center';
var u251 = document.getElementById('u251');
gv_vAlignTable['u251'] = 'center';
var u121 = document.getElementById('u121');

var u164 = document.getElementById('u164');
gv_vAlignTable['u164'] = 'center';
var u298 = document.getElementById('u298');
gv_vAlignTable['u298'] = 'center';
var u177 = document.getElementById('u177');

u177.style.cursor = 'pointer';
if (bIE) u177.attachEvent("onclick", Clicku177);
else u177.addEventListener("click", Clicku177, true);
function Clicku177(e)
{

if (true) {

	SetPanelVisibilityu64("hidden");

}

}

var u448 = document.getElementById('u448');

var u301 = document.getElementById('u301');

var u142 = document.getElementById('u142');
gv_vAlignTable['u142'] = 'top';
var u363 = document.getElementById('u363');

var u159 = document.getElementById('u159');
gv_vAlignTable['u159'] = 'top';
var u507 = document.getElementById('u507');
gv_vAlignTable['u507'] = 'center';
var u340 = document.getElementById('u340');
gv_vAlignTable['u340'] = 'top';
var u29 = document.getElementById('u29');
gv_vAlignTable['u29'] = 'top';
var u367 = document.getElementById('u367');

var u44 = document.getElementById('u44');

u44.style.cursor = 'pointer';
if (bIE) u44.attachEvent("onclick", Clicku44);
else u44.addEventListener("click", Clicku44, true);
function Clicku44(e)
{

if (true) {

	self.location.href="大地图.html" + GetQuerystring();

}

}

var u425 = document.getElementById('u425');
gv_vAlignTable['u425'] = 'top';
var u563 = document.getElementById('u563');
gv_vAlignTable['u563'] = 'center';
var u84 = document.getElementById('u84');
gv_vAlignTable['u84'] = 'center';
var u124 = document.getElementById('u124');

var u76 = document.getElementById('u76');
gv_vAlignTable['u76'] = 'center';
var u223 = document.getElementById('u223');
gv_vAlignTable['u223'] = 'top';
var u380 = document.getElementById('u380');
gv_vAlignTable['u380'] = 'top';
var u530 = document.getElementById('u530');

var u548 = document.getElementById('u548');

var u218 = document.getElementById('u218');
gv_vAlignTable['u218'] = 'top';
var u17 = document.getElementById('u17');
gv_vAlignTable['u17'] = 'top';
var u267 = document.getElementById('u267');
gv_vAlignTable['u267'] = 'center';
var u161 = document.getElementById('u161');

var u388 = document.getElementById('u388');

u388.style.cursor = 'pointer';
if (bIE) u388.attachEvent("onclick", Clicku388);
else u388.addEventListener("click", Clicku388, true);
function Clicku388(e)
{

if (true) {

	SetPanelVisibilityu64("");

	SetPanelVisibilityu308("hidden");

}

}
gv_vAlignTable['u388'] = 'top';
var u538 = document.getElementById('u538');

var u405 = document.getElementById('u405');
gv_vAlignTable['u405'] = 'top';
var u22 = document.getElementById('u22');

var u272 = document.getElementById('u272');
gv_vAlignTable['u272'] = 'center';
var u542 = document.getElementById('u542');

u542.style.cursor = 'pointer';
if (bIE) u542.attachEvent("onclick", Clicku542);
else u542.addEventListener("click", Clicku542, true);
function Clicku542(e)
{

if (true) {

	SetPanelVisibilityu523("hidden");

	SetPanelVisibilityu573("hidden");

}

}

var u38 = document.getElementById('u38');

var u112 = document.getElementById('u112');

var u53 = document.getElementById('u53');
gv_vAlignTable['u53'] = 'center';
var u250 = document.getElementById('u250');

var u49 = document.getElementById('u49');
gv_vAlignTable['u49'] = 'center';
var u93 = document.getElementById('u93');
gv_vAlignTable['u93'] = 'top';
var u481 = document.getElementById('u481');
gv_vAlignTable['u481'] = 'center';
var u473 = document.getElementById('u473');
gv_vAlignTable['u473'] = 'center';
var u313 = document.getElementById('u313');

var u483 = document.getElementById('u483');
gv_vAlignTable['u483'] = 'center';
var u492 = document.getElementById('u492');
gv_vAlignTable['u492'] = 'center';
var u181 = document.getElementById('u181');
gv_vAlignTable['u181'] = 'top';
var u357 = document.getElementById('u357');

var u543 = document.getElementById('u543');
gv_vAlignTable['u543'] = 'center';
var u265 = document.getElementById('u265');
gv_vAlignTable['u265'] = 'center';
var u562 = document.getElementById('u562');

var u189 = document.getElementById('u189');

var u339 = document.getElementById('u339');
gv_vAlignTable['u339'] = 'top';
var u494 = document.getElementById('u494');
gv_vAlignTable['u494'] = 'center';
var u2 = document.getElementById('u2');
gv_vAlignTable['u2'] = 'top';
var u156 = document.getElementById('u156');
gv_vAlignTable['u156'] = 'top';
var u62 = document.getElementById('u62');

var u409 = document.getElementById('u409');

var u513 = document.getElementById('u513');
gv_vAlignTable['u513'] = 'top';
var u354 = document.getElementById('u354');

var u79 = document.getElementById('u79');
gv_vAlignTable['u79'] = 'top';
var u579 = document.getElementById('u579');
gv_vAlignTable['u579'] = 'center';
var u403 = document.getElementById('u403');
gv_vAlignTable['u403'] = 'top';
var u243 = document.getElementById('u243');

var u114 = document.getElementById('u114');
gv_vAlignTable['u114'] = 'top';
var u404 = document.getElementById('u404');

var u245 = document.getElementById('u245');
gv_vAlignTable['u245'] = 'top';
var u536 = document.getElementById('u536');

var u297 = document.getElementById('u297');

var u247 = document.getElementById('u247');
gv_vAlignTable['u247'] = 'top';
var u497 = document.getElementById('u497');
gv_vAlignTable['u497'] = 'top';
var u148 = document.getElementById('u148');

var u274 = document.getElementById('u274');
gv_vAlignTable['u274'] = 'center';
var u436 = document.getElementById('u436');
gv_vAlignTable['u436'] = 'top';
var u175 = document.getElementById('u175');
gv_vAlignTable['u175'] = 'top';
var u472 = document.getElementById('u472');

var u429 = document.getElementById('u429');
gv_vAlignTable['u429'] = 'top';
var u464 = document.getElementById('u464');
gv_vAlignTable['u464'] = 'center';
var u176 = document.getElementById('u176');

u176.style.cursor = 'pointer';
if (bIE) u176.attachEvent("onclick", Clicku176);
else u176.addEventListener("click", Clicku176, true);
function Clicku176(e)
{

if (true) {

	SetPanelVisibilityu194("");

}

}

var u71 = document.getElementById('u71');
gv_vAlignTable['u71'] = 'top';
var u557 = document.getElementById('u557');

var u200 = document.getElementById('u200');

var u396 = document.getElementById('u396');
gv_vAlignTable['u396'] = 'top';
var u470 = document.getElementById('u470');

var u551 = document.getElementById('u551');

var u10 = document.getElementById('u10');

var u423 = document.getElementById('u423');

var u158 = document.getElementById('u158');
gv_vAlignTable['u158'] = 'top';
var u496 = document.getElementById('u496');
gv_vAlignTable['u496'] = 'top';
var u217 = document.getElementById('u217');
gv_vAlignTable['u217'] = 'top';
var u478 = document.getElementById('u478');

var u495 = document.getElementById('u495');
gv_vAlignTable['u495'] = 'top';
var u15 = document.getElementById('u15');

var u155 = document.getElementById('u155');
gv_vAlignTable['u155'] = 'center';
var u511 = document.getElementById('u511');
gv_vAlignTable['u511'] = 'top';
var u249 = document.getElementById('u249');

u249.style.cursor = 'pointer';
if (bIE) u249.attachEvent("onclick", Clicku249);
else u249.addEventListener("click", Clicku249, true);
function Clicku249(e)
{

if (true) {

	SetPanelVisibilityu296("");

}

}

var u235 = document.getElementById('u235');
gv_vAlignTable['u235'] = 'center';
var u47 = document.getElementById('u47');
gv_vAlignTable['u47'] = 'center';
var u392 = document.getElementById('u392');

var u413 = document.getElementById('u413');

var u287 = document.getElementById('u287');
gv_vAlignTable['u287'] = 'top';
var u87 = document.getElementById('u87');
gv_vAlignTable['u87'] = 'top';
var u266 = document.getElementById('u266');

var u91 = document.getElementById('u91');
gv_vAlignTable['u91'] = 'center';
var u7 = document.getElementById('u7');

var u560 = document.getElementById('u560');

var u110 = document.getElementById('u110');

var u271 = document.getElementById('u271');

var u307 = document.getElementById('u307');

u307.style.cursor = 'pointer';
if (bIE) u307.attachEvent("onclick", Clicku307);
else u307.addEventListener("click", Clicku307, true);
function Clicku307(e)
{

if (true) {

	SetPanelVisibilityu236("hidden");

	SetPanelVisibilityu296("hidden");

}

}

var u174 = document.getElementById('u174');
gv_vAlignTable['u174'] = 'top';
var u471 = document.getElementById('u471');
gv_vAlignTable['u471'] = 'center';
var u24 = document.getElementById('u24');

u24.style.cursor = 'pointer';
if (bIE) u24.attachEvent("onclick", Clicku24);
else u24.addEventListener("click", Clicku24, true);
function Clicku24(e)
{

if (true) {

	self.location.href="自宅订单.html" + GetQuerystring();

}

}

var u556 = document.getElementById('u556');
gv_vAlignTable['u556'] = 'center';
var u312 = document.getElementById('u312');
gv_vAlignTable['u312'] = 'center';
var u56 = document.getElementById('u56');

var u482 = document.getElementById('u482');

var u263 = document.getElementById('u263');
gv_vAlignTable['u263'] = 'top';
var u193 = document.getElementById('u193');

var u343 = document.getElementById('u343');
gv_vAlignTable['u343'] = 'top';
var u197 = document.getElementById('u197');

var u188 = document.getElementById('u188');
gv_vAlignTable['u188'] = 'center';
var u248 = document.getElementById('u248');
gv_vAlignTable['u248'] = 'top';
var u338 = document.getElementById('u338');
gv_vAlignTable['u338'] = 'top';
var u457 = document.getElementById('u457');
gv_vAlignTable['u457'] = 'center';
var u437 = document.getElementById('u437');

var u575 = document.getElementById('u575');
gv_vAlignTable['u575'] = 'center';
var u18 = document.getElementById('u18');
gv_vAlignTable['u18'] = 'top';
if (window.OnLoad) OnLoad();
